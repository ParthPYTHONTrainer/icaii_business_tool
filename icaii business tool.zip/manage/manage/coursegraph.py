import pandas as pd
from matplotlib import pyplot as plt
from tkinter import filedialog

def cou():
    ff = filedialog.askopenfile()
    # df=pd.read_csv(ff)
    course=pd.read_csv(ff, usecols=[1])
    plt.figure(figsize=(16,9))    #graph size 
    plt.title("Course", fontsize=20)
    plt.ylabel("Course")
    plt.hist(course,rwidth=0.7,color="r", edgecolor='k')
    plt.show()

    
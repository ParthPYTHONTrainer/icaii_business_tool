from tkinter import*
from tkinter import Toplevel, messagebox, filedialog #Toplevel for window like pop up, filedialog for ask where open or save file
import time
from tkinter.ttk import Treeview
from tkinter import ttk
import pymysql
import pandas
from tkcalendar import*
from end_date import*
import csv
from subplotgraph import gra
from qualgraph import qua
from coursegraph import cou
from durationgraph import dua

#--------------------------------------------------------------------------------------------------------------------------------

def addstudent():
    def submitadd():

        reg = regval.get()
        courses = coursesval.get()
        dur=durationval.get()
        duration1=dur.split(" : ")
        duration=duration1[1]
        totalfees = totalfeesval.get()
        receivedfees = receivedfeesval.get()
        duefees = str(int(totalfees)-int(receivedfees))
        qual = qualval.get()
        startdate = startdateval.get()
        enddate = end_date(duration,startdate)
        fname = fnameval.get()
        mobile = mobileval.get()
        parentname = parentnameval.get()
        address = addressval.get()
        
        try:
            strr =  'insert into studentdata1 values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
            mycursor = con.cursor()
            mycursor.execute(strr,(reg, courses, duration, totalfees, receivedfees, duefees,
                                    qual, startdate, enddate, fname, mobile, parentname, address))
            con.commit()
            res = messagebox.askyesnocancel('Notifications',"Registration {} Name {} Added Sucessfully.. & want to clean the form".format(reg, fname), parent=addroot)
            if(res==True):
                regval.set('')
                coursesval.set('')
                durationval.set('')
                totalfeesval.set('')
                receivedfeesval.set('')
                duefeesval.set('')
                qualval.set('')
                startdateval.set('')
                enddateval.set('')
                fnameval.set('')
                mobileval.set('')
                parentnameval.set('')
                addressval.set('')
        except:
            messagebox.showerror('Notifications', 'Registration No. Already Exist try onther Registration No.', parent=addroot)
        strr = 'select * from studentdata1'
        mycursor = con.cursor()
        mycursor.execute(strr)
        
        datas = mycursor.fetchall()
        studenttable.delete(*studenttable.get_children())
        for i in datas:
            vv = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
            studenttable.insert('', END, values=vv)
#--------------------------------------------------------------------------------------------------------------------------------   
    addroot = Toplevel(master=DataEntryFrame)
    addroot.grab_set() # when use window not use another
    addroot.geometry('470x505+220+200')
    addroot.title('Add Student')
    addroot.config(bg='#B09B71')
    addroot.iconbitmap('icon.ico')
    addroot.resizable(False, False)
#--------------------------------------------------------------------------------------------------------------------------------
    # Add Student Label
    reglabel = Label(addroot, text='Registration No.:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    reglabel.place(x=10, y=10)

    courseslabel = Label(addroot, text='The Available Courses:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    courseslabel.place(x=10, y=50)

    durationlabel = Label(addroot, text='Duration:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    durationlabel.place(x=10, y=90)

    totalfeeslabel = Label(addroot, text='Total fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    totalfeeslabel.place(x=10, y=130)

    receivedfeeslabel = Label(addroot, text='Received Fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    receivedfeeslabel.place(x=10, y=170)

    # duefeeslabel = Label(addroot, text='Due Fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    # duefeeslabel.place(x=10, y=210)

    quallabel = Label(addroot, text='Qualification:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    quallabel.place(x=10, y=210)

    startdatelabel = Label(addroot, text='Start Date:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    startdatelabel.place(x=10, y=250)

    # enddatelabel = Label(addroot, text='End Date:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    # enddatelabel.place(x=10, y=330)

    fnamelabel = Label(addroot, text='Full Name:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    fnamelabel.place(x=10, y=290)

    mobilelabel = Label(addroot, text='Mobile No.:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    mobilelabel.place(x=10, y=330)

    parentnamelabel = Label(addroot, text="Parent's Name:", bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    parentnamelabel.place(x=10, y=370)

    addresslabel = Label(addroot, text='Address:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    addresslabel.place(x=10, y=410)
#--------------------------------------------------------------------------------------------------------------------------------
    #Add Student Entry
    regval = StringVar()
    coursesval = StringVar()
    durationval = StringVar()
    totalfeesval = StringVar()
    receivedfeesval = StringVar()
    duefeesval = StringVar()
    qualval = StringVar()
    startdateval = StringVar()
    enddateval = StringVar()
    fnameval = StringVar()
    mobileval = StringVar()
    parentnameval = StringVar()
    addressval = StringVar()
    
    regentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=regval)
    regentry.place(x=250, y=10)

    coursesentry= ttk.Combobox(addroot, textvariable=coursesval, font=("times new roman", 15, "bold"), state="readonly")
    coursesentry["values"] = ("Select", "Python", "C/C++", "PHP", "Web Devlopment", "Digital Marketing","Java","Data Science","AI")
    coursesentry.place(x=250, y=50, width=208)
    
    durationentry= ttk.Combobox(addroot, textvariable=durationval, font=("times new roman", 15, "bold"), state="readonly")
    durationentry["values"] = ("Select","1 : 1m", "2 : 6w", "3 : 2m", "4 : 3m", "5 : 6m", "6 : 1y")
    durationentry.place(x=250, y=90, width=208)    

    totalfeesentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=totalfeesval)
    totalfeesentry.place(x=250, y=130)

    receivedfeesentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=receivedfeesval)
    receivedfeesentry.place(x=250, y=170)

    # duefeesentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=duefeesval)
    # duefeesentry.place(x=250, y=210)

    qualentry = ttk.Combobox(addroot, textvariable=qualval, font=('times new roman', 15, 'bold'), state="readonly")
    qualentry["values"] = ("Select", "10th", "+2", "Diploma", "Graduate", "Post Graduate")
    qualentry.place(x=250, y=210, width=208)

    def pick_date(event):
        global cal, date_window

        date_window = Toplevel()
        date_window.grab_set()
        date_window.title("Choose Date")
        date_window.geometry('250x220+590+370')
        cal = Calendar(date_window, selectmode = "day", date_pattern = "dd/mm/yyyy")
        cal.place(x=0, y=0)

        submit_btn = Button(date_window, text = "Submit", command = grab_date)
        submit_btn.place(x=80, y=190)

    def grab_date():
        startdateentry.delete(0, END)
        startdateentry.insert(0, cal.get_date())
        date_window.destroy()

    startdateentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=startdateval)
    startdateentry.place(x=250, y=250, width=208)
    startdateentry.insert(0, "dd/mm/yyyy")
    startdateentry.bind("<1>", pick_date)
    
    
    # enddateentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=enddateval)
    # enddateentry.place(x=250, y=330)
    # enddateentry.insert(0, "dd/mm/yyyy")

    fnameentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=fnameval)
    fnameentry.place(x=250, y=290)

    mobileentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=mobileval)
    mobileentry.place(x=250, y=330)
    mobileentry.insert(0, "+91")

    parentnameentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=parentnameval)
    parentnameentry.place(x=250, y=370)

    addressentry = Entry(addroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=addressval)
    addressentry.place(x=250, y=410)
#--------------------------------------------------------------------------------------------------------------------------------
    #Submit Button
    submitbtn = Button(addroot, text='Submit', font=('times new roman', 15, 'bold'), width=20, bd=5, activebackground="#EDDFB3",
                        bg='#87805E', command=submitadd)
    submitbtn.place(x=110, y=450)
 
    addroot.mainloop()
##################################################################################################################################### 

def searchstudent():
    def search():
        reg = regval.get()
        courses = coursesval.get()
        duration = durationval.get()
        totalfees = totalfeesval.get()
        receivedfees = receivedfeesval.get()
        duefees = duefeesval.get()
        qual = qualval.get()
        startdate = startdateval.get()
        enddate = enddateval.get()
        fname = fnameval.get()
        mobile = mobileval.get()
        parentname = parentnameval.get()
        address = addressval.get()
        
        if(reg !=''):
            
            strr = 'select * from studentdata1 where reg=%s'
            mycursor.execute(strr,(reg))
            datas = mycursor.fetchall()
            studenttable.delete(*studenttable.get_children())
            for i in datas:
                vv = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
                studenttable.insert('', END, values=vv)

        elif(fname !=''):
            
            strr = 'select * from studentdata1 where fname=%s'
            mycursor.execute(strr,(fname))
            datas = mycursor.fetchall()
            studenttable.delete(*studenttable.get_children())
            for i in datas:
                vv = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
                studenttable.insert('', END, values=vv)

        elif(mobile !=''):
            
            strr = 'select * from studentdata1 where mobile=%s'
            mycursor.execute(strr,(mobile))
            datas = mycursor.fetchall()
            studenttable.delete(*studenttable.get_children())
            for i in datas:
                vv = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
                studenttable.insert('', END, values=vv)

        elif(parentname !=''):
            
            strr = 'select * from studentdata1 where parentname=%s'
            mycursor.execute(strr,(parentname))
            datas = mycursor.fetchall()
            studenttable.delete(*studenttable.get_children())
            for i in datas:
                vv = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
                studenttable.insert('', END, values=vv)

        elif(qual !=''):
            
            strr = 'select * from studentdata1 where qual=%s'
            mycursor.execute(strr,(qual))
            datas = mycursor.fetchall()
            studenttable.delete(*studenttable.get_children())
            for i in datas:
                vv = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
                studenttable.insert('', END, values=vv)

#--------------------------------------------------------------------------------------------------------------------------------

    searchroot = Toplevel(master=DataEntryFrame)
    searchroot.grab_set() # when use window not use another
    searchroot.geometry('470x505+220+200')
    searchroot.title('Search Student')
    searchroot.config(bg='#B09B71')
    searchroot.iconbitmap('icon.ico')
    searchroot.resizable(False, False)
#--------------------------------------------------------------------------------------------------------------------------------
    # Add Student Label
    reglabel = Label(searchroot, text='Registration No.:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    reglabel.place(x=10, y=10)

    courseslabel = Label(searchroot, text='The Available Courses:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    courseslabel.place(x=10, y=50)

    durationlabel = Label(searchroot, text='Duration:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    durationlabel.place(x=10, y=90)

    totalfeeslabel = Label(searchroot, text='Total fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    totalfeeslabel.place(x=10, y=130)

    receivedfeeslabel = Label(searchroot, text='Received Fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    receivedfeeslabel.place(x=10, y=170)

    # duefeeslabel = Label(searchroot, text='Due Fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    # duefeeslabel.place(x=10, y=210)

    quallabel = Label(searchroot, text='Qualification:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    quallabel.place(x=10, y=210)

    startdatelabel = Label(searchroot, text='Start Date:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    startdatelabel.place(x=10, y=250)

    # enddatelabel = Label(searchroot, text='End Date:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    # enddatelabel.place(x=10, y=330)

    fnamelabel = Label(searchroot, text='Full Name:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    fnamelabel.place(x=10, y=290)

    mobilelabel = Label(searchroot, text='Mobile No.:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    mobilelabel.place(x=10, y=330)

    parentnamelabel = Label(searchroot, text="Parent's Name:", bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    parentnamelabel.place(x=10, y=370)

    addresslabel = Label(searchroot, text='Address:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    addresslabel.place(x=10, y=410)
#--------------------------------------------------------------------------------------------------------------------------------
    #Add Student Entry
    regval = StringVar()
    coursesval = StringVar()
    durationval = StringVar()
    totalfeesval = StringVar()
    receivedfeesval = StringVar()
    duefeesval = StringVar()
    qualval = StringVar()
    startdateval = StringVar()
    enddateval = StringVar()
    fnameval = StringVar()
    mobileval = StringVar()
    parentnameval = StringVar()
    addressval = StringVar()

    regentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=regval)
    regentry.place(x=250, y=10)

    coursesentry= ttk.Combobox(searchroot, textvariable=coursesval, font=("times new roman", 15, "bold"), state="readonly")
    coursesentry["values"] = ("Select", "Python", "C/C++", "PHP", "Web Devlopment", "Digital Marketing","Java","Data Science","AI")
    coursesentry.place(x=250, y=50, width=208)

    durationentry= ttk.Combobox(searchroot, textvariable=durationval, font=("times new roman", 15, "bold"), state="readonly")
    durationentry["values"] = ("Select","1 : 1m", "2 : 6w", "3 : 2m", "4 : 3m", "5 : 6m", "6 : 1y")
    durationentry.place(x=250, y=90, width=208)

    totalfeesentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=totalfeesval)
    totalfeesentry.place(x=250, y=130)

    receivedfeesentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=receivedfeesval)
    receivedfeesentry.place(x=250, y=170)

    # duefeesentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=duefeesval)
    # duefeesentry.place(x=250, y=210)

    qualentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=qualval)
    qualentry.place(x=250, y=210)

    startdateentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=startdateval)
    startdateentry.place(x=250, y=250)

    # enddateentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=enddateval)
    # enddateentry.place(x=250, y=330)
    # enddateentry.insert(0, "dd/mm/yyyy")

    fnameentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=fnameval)
    fnameentry.place(x=250, y=290)

    mobileentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=mobileval)
    mobileentry.place(x=250, y=330)
    mobileentry.insert(0, "+91")

    parentnameentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=parentnameval)
    parentnameentry.place(x=250, y=370)

    addressentry = Entry(searchroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=addressval)
    addressentry.place(x=250, y=410)
#--------------------------------------------------------------------------------------------------------------------------------
    #Search Button
    searchbtn = Button(searchroot, text='Search', font=('times new roman', 15, 'bold'), width=20, bd=5, activebackground="#EDDFB3",
                        bg='#87805E', command=search)
    searchbtn.place(x=110, y=450)
 
    searchroot.mainloop()
 
##################################################################################################################################### 
def deletestudent():
    cc = studenttable.focus()
    content = studenttable.item(cc)
    pp = content['values'][0]
    strr = 'delete from studentdata1 where reg=%s'
    mycursor.execute(strr,(pp))
    con.commit()
    messagebox.showinfo('Notifications', 'Registration {} deleted..'.format(pp))         
    
    strr = 'select * from studentdata1'
    mycursor.execute(strr)
    datas = mycursor.fetchall()
    studenttable.delete(*studenttable.get_children())
    for i in datas:
        vv1 = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
        studenttable.insert('', END, values=vv1)

##################################################################################################################################### 
def updatestudent():
    def update():
        reg = regval.get()
        courses = coursesval.get()
        dur=durationval.get()
        duration1=dur.split(" : ")
        duration=duration1[1]
        totalfees = totalfeesval.get()
        receivedfees = receivedfeesval.get()
        duefees = str(int(totalfees)-int(receivedfees))
        qual = qualval.get()
        startdate = startdateval.get()
        enddate = end_date(duration,startdate)
        fname = fnameval.get()
        mobile = mobileval.get()
        parentname = parentnameval.get()
        address = addressval.get()

        strr = 'update studentdata1 set courses=%s, duration=%s, totalfees=%s, receivedfees=%s, duefees=%s, qual=%s, startdate=%s, enddate=%s, fname=%s, mobile=%s, parentname=%s, address=%s where reg=%s'
        mycursor.execute(strr,(courses, duration, totalfees, receivedfees, duefees, qual, startdate, enddate, fname, mobile, parentname, address,reg))
        con.commit()
        messagebox.showinfo('Notifications', 'Registration {} Update Sucessfull..'.format(reg), parent=updateroot )
        strr = 'select * from studentdata1'
        mycursor.execute(strr)
        datas = mycursor.fetchall()
        studenttable.delete(*studenttable.get_children())
        for i in datas:
            vv1 = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
            studenttable.insert('', END, values=vv1)

        
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    updateroot = Toplevel(master=DataEntryFrame)
    updateroot.grab_set() # when use window not use another
    updateroot.geometry('470x505+220+200')
    updateroot.title('Update Student Data')
    updateroot.config(bg='#B09B71')
    updateroot.iconbitmap('icon.ico')
    updateroot.resizable(False, False)
#--------------------------------------------------------------------------------------------------------------------------------
    # Add Student Label
    reglabel = Label(updateroot, text='Registration No.:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    reglabel.place(x=10, y=10)

    courseslabel = Label(updateroot, text='The Available Courses:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    courseslabel.place(x=10, y=50)

    durationlabel = Label(updateroot, text='Duration:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    durationlabel.place(x=10, y=90)

    totalfeeslabel = Label(updateroot, text='Total fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    totalfeeslabel.place(x=10, y=130)

    receivedfeeslabel = Label(updateroot, text='Received Fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    receivedfeeslabel.place(x=10, y=170)

    # duefeeslabel = Label(updateroot, text='Due Fees:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    # duefeeslabel.place(x=10, y=210)

    quallabel = Label(updateroot, text='Qualification:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    quallabel.place(x=10, y=210)

    startdatelabel = Label(updateroot, text='Start Date:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    startdatelabel.place(x=10, y=250)

    # enddatelabel = Label(updateroot, text='End Date:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    # enddatelabel.place(x=10, y=330)

    fnamelabel = Label(updateroot, text='Full Name:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    fnamelabel.place(x=10, y=290)

    mobilelabel = Label(updateroot, text='Mobile No.:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    mobilelabel.place(x=10, y=330)

    parentnamelabel = Label(updateroot, text="Parent's Name:", bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    parentnamelabel.place(x=10, y=370)

    addresslabel = Label(updateroot, text='Address:', bg = '#A27B5C', font=('times new roman',15, 'bold'), relief=GROOVE, borderwidth=3, width=17, anchor='w')
    addresslabel.place(x=10, y=410)
#--------------------------------------------------------------------------------------------------------------------------------
    #Add Student Entry
    regval = StringVar()
    coursesval = StringVar()
    durationval = StringVar()
    totalfeesval = StringVar()
    receivedfeesval = StringVar()
    duefeesval = StringVar()
    qualval = StringVar()
    startdateval = StringVar()
    enddateval = StringVar()
    fnameval = StringVar()
    mobileval = StringVar()
    parentnameval = StringVar()
    addressval = StringVar()

    regentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=regval)
    regentry.place(x=250, y=10)

    coursesentry= ttk.Combobox(updateroot, textvariable=coursesval, font=("times new roman", 15, "bold"), state="readonly")
    coursesentry["values"] = ("Select", "Python", "C/C++", "PHP", "Web Devlopment", "Digital Marketing","Java","Data Science","AI")
    coursesentry.place(x=250, y=50, width=208)

    durationentry= ttk.Combobox(updateroot, textvariable=durationval, font=("times new roman", 15, "bold"), state="readonly")
    durationentry["values"] = ("Select","1 : 1m", "2 : 6w", "3 : 2m", "4 : 3m", "5 : 6m", "6 : 1y")
    durationentry.place(x=250, y=90, width=208)

    totalfeesentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=totalfeesval)
    totalfeesentry.place(x=250, y=130)

    receivedfeesentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=receivedfeesval)
    receivedfeesentry.place(x=250, y=170)

    # duefeesentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=duefeesval)
    # duefeesentry.place(x=250, y=210)

    qualentry = ttk.Combobox(updateroot, textvariable=qualval, font=('times new roman', 15, 'bold'), state="readonly")
    qualentry["values"] = ("Select", "10th", "+2", "Diploma", "Graduate", "Post Graduate")
    qualentry.place(x=250, y=210, width=208)

    def pick_date(event):
        global cal, date_window

        date_window = Toplevel()
        date_window.grab_set()
        date_window.title("Choose Date")
        date_window.geometry('250x220+590+370')
        cal = Calendar(date_window, selectmode = "day", date_pattern = "dd/mm/yyyy")
        cal.place(x=0, y=0)

        submit_btn = Button(date_window, text = "Submit", command = grab_date)
        submit_btn.place(x=80, y=190)

    def grab_date():
        startdateentry.delete(0, END)
        startdateentry.insert(0, cal.get_date())
        date_window.destroy()

    startdateentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=startdateval)
    startdateentry.place(x=250, y=250, width=208)
    startdateentry.insert(0, "dd/mm/yyyy")
    startdateentry.bind("<1>", pick_date)

    # enddateentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=enddateval)
    # enddateentry.place(x=250, y=330)
    # enddateentry.insert(0, "dd/mm/yyyy")

    fnameentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=fnameval)
    fnameentry.place(x=250, y=290)

    mobileentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=mobileval)
    mobileentry.place(x=250, y=330)
    mobileentry.insert(0, "+91")

    parentnameentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=parentnameval)
    parentnameentry.place(x=250, y=370)

    addressentry = Entry(updateroot, font=('times new roman', 15, 'bold'), bd=3, textvariable=addressval)
    addressentry.place(x=250, y=410)
#--------------------------------------------------------------------------------------------------------------------------------
    #Update Button
    updatebtn = Button(updateroot, text='Update', font=('times new roman', 15, 'bold'), width=20, bd=5, activebackground="#EDDFB3",
                        bg='#87805E', command=update)
    updatebtn.place(x=110, y=450)

    cc = studenttable.focus()
    content = studenttable.item(cc)
    pp = content['values']
    if(len(pp) !=0):
        regval.set(pp[0])
        coursesval.set(pp[1])
        durationval.set(pp[2])
        totalfeesval.set(pp[3])
        receivedfeesval.set(pp[4])
        duefeesval.set(pp[5])
        qualval.set(pp[6])
        startdateval.set(pp[7])
        enddateval.set(pp[8])
        fnameval.set(pp[9])
        mobileval.set(pp[10])
        parentnameval.set(pp[11])
        addressval.set(pp[12])
    updateroot.mainloop()
##################################################################################################################################### 
def showallstudent():
    strr = 'select * from studentdata1'
    mycursor.execute(strr)
    datas = mycursor.fetchall()
    studenttable.delete(*studenttable.get_children())
    for i in datas:
        vv1 = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12]]
        studenttable.insert('', END, values=vv1)
##################################################################################################################################### 
def exportstudent():
    ff = filedialog.asksaveasfilename()
    gg = studenttable.get_children()
    reg, courses, duration, totalfees, receivedfees, duefees, qual, startdate, enddate, fname, mobile, parentname, address = [], [], [], [], [], [], [], [], [], [], [], [], []
    for i in gg:
        content = studenttable.item(i)
        pp = content['values']
        reg.append(pp[0]), courses.append(pp[1]), duration.append(pp[2]), totalfees.append(pp[3]), receivedfees.append(pp[4]), duefees.append(pp[5]),
        qual.append(pp[6]), startdate.append(pp[7]), enddate.append(pp[8]), fname.append(pp[9]), mobile.append(pp[10]), parentname.append(pp[11]), address.append(pp[12])
        dd = ['Registration', 'The Available Courses', 'Duration', 'The Total Fees', 'Received Fees', 'Due Fees', 'Qualification', 'Start Date', 'End Date', 'Full Name',
              'Mobile No.', "Parent's Name", 'Address']
        df = pandas.DataFrame(list(zip(reg, courses, duration, totalfees, receivedfees, duefees, qual, startdate, enddate, fname,
                                        mobile, parentname, address)),columns=dd)
        paths = r'{}.csv'.format(ff)
        df.to_csv(paths,index=False)
    messagebox.showinfo('Notifications', 'Student data is Saved {}'.format(paths))
##################################################################################################################################### 
def exportgraphs():
    # ff = filedialog.askopenfile()
    # pass
    graph_window = Toplevel()
    graph_window.grab_set()
    graph_window.title("Graphs")
    graph_window.geometry('500x590+210+150')
    graph_window.resizable(False, False)
    graph_window.config(bg='#EDDFB3')
    graph_window.iconbitmap('courseicon.ico')

    graphsframewindow = Frame(graph_window,bg ="#B09B71", relief=GROOVE, borderwidth=5)
    graphsframewindow.place(x=10, y=20, width=480, height=550)


    frontlabel = Label(graph_window, text = "-----Data Analysis-----", width=25, font=('times new roman', 22, 'bold'), bg='#87805E')
    frontlabel.pack(side=TOP, expand=True)

    qualbtn = Button(graph_window, text='1. Qualification', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                     command=qua)
    qualbtn.pack(side=TOP, expand=True)

    durationbtn = Button(graph_window, text='2. Duration', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                     command=dua)
    durationbtn.pack(side=TOP, expand=True)

    coursebtn = Button(graph_window, text='3. Course', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                     command=cou)
    coursebtn.pack(side=TOP, expand=True)

    subplotbtn = Button(graph_window, text='4. Subplot', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                     command=gra)
    subplotbtn.pack(side=TOP, expand=True)

    graph_window.mainloop()



##################################################################################################################################### 
def exit():
    res = messagebox.askyesnocancel('Notification', 'Do you want to exit?')
    if(res==True):
        root.destroy()
##################################################################################################################################### 

def Connectdb():
    def submitdb():
        global con, mycursor
        host = hostval.get()
        user = userval.get()
        password = passwordval.get()
        try:
            con = pymysql.connect(host=host, user=user, password=password)
            mycursor = con.cursor()
        except:
            messagebox.showerror('Notification', 'Data is Incorrect, Please try again', parent=dbroot)
            return
        try:
            strr = 'create database studentanalysissystem1'
            mycursor.execute(strr)
            strr = 'use studentanalysissystem1'
            mycursor.execute(strr)
            strr = 'create table studentdata1(reg int, courses varchar(25), duration varchar(10), totalfees int, receivedfees int, duefees int, qual varchar(20), startdate varchar(255), enddate varchar(255), fname varchar(20), mobile varchar(20), parentname varchar(20), address varchar(20))'
            mycursor.execute(strr)
            strr = 'alter table studentdata1 modify column reg int not null'
            mycursor.execute(strr)
            strr = 'alter table studentdata1 modify column reg int primary key'
            mycursor.execute(strr)
            strr = 'alter table studentdata1 modify column reg int auto_increment'
            mycursor.execute(strr)
            messagebox.showinfo('Notification',' Database Created and Now you are Connected to the Database....', parent = dbroot)
        except:
            strr = 'use studentanalysissystem1'
            mycursor.execute(strr)
            messagebox.showinfo('Notification',' Now You are Connected to the Database....', parent = dbroot)
        dbroot.destroy()
            
#--------------------------------------------------------------------------------------------------------------------------------
    dbroot = Toplevel()
    dbroot.grab_set()
    dbroot.geometry("470x250+800+230") # after+ side space
    dbroot.title("Data Base")
    dbroot.iconbitmap("database.ico")
    dbroot.resizable(False, False)    #non adjustable
    dbroot.config(bg='#B09B71')
#--------------------------------------------------------------------------------------------------------------------------------
    #ConnectDB Labels
    hostlabel = Label(dbroot, text = "Enter Host:", bg = "#A27B5C", font=('times new roman', 20, 'bold'), relief=GROOVE, borderwidth=3, width=13, anchor='w')
    hostlabel.place(x=10, y=10)

    userlabel = Label(dbroot, text = "Enter User:", bg = "#A27B5C", font=('times new roman', 20, 'bold'), relief=GROOVE, borderwidth=3, width=13, anchor='w')
    userlabel.place(x=10, y=70)

    passwordlabel = Label(dbroot, text = "Enter Password:", bg = "#A27B5C", font=('times new roman', 20, 'bold'), relief=GROOVE, borderwidth=3, width=13, anchor='w')
    passwordlabel.place(x=10, y=130)

#--------------------------------------------------------------------------------------------------------------------------------
    #Connectdb Entry
    hostval = StringVar()
    userval = StringVar()
    passwordval = StringVar()

    hostentry = Entry(dbroot, font=('times new roman', 15, 'bold'), bd=5, textvariable=hostval)
    hostentry.place(x=250, y=10)

    userentry = Entry(dbroot, font=('times new roman', 15, 'bold'), bd=5, textvariable=userval)
    userentry.place(x=250, y=70)

    passwordentry = Entry(dbroot, font=('times new roman', 15, 'bold'), bd=5, show='*', textvariable=passwordval)
    passwordentry.place(x=250, y=130)
    #---------------------------------------------
    submitbutton = Button(dbroot, text="Submit", font=('times new roman',15, 'bold'), width=20,bg='#87805E',bd=5, activebackground="#EDDFB3", command=submitdb)
    submitbutton.place(x=150, y=190)

    dbroot.mainloop()
##################################################################################################################################### 
def tick():
    time_string = time.strftime("%H:%M:%S")
    date_string = time.strftime("%d/%m/%Y")
    clock.config(text="Date:"+date_string+"\n"+"Time:"+time_string)
    clock.after(200,tick)
##################################################################################################################################### 
def IntroLabelTick():
    global count, text
    if(count>=len(ss)):
        count = 0
        text = ""
        SliderLabel.config(text=text)
    else:
        text = text + ss[count]
        SliderLabel.config(text=text)
        count += 1
    SliderLabel.after(200,IntroLabelTick) #MicroSecond
    
##################################################################################################################################### 
#Main Frame
root = Tk()
root.title("ICAII")
root.config(bg="#EDDFB3")
root.geometry("1174x700+200+50")
root.iconbitmap("icaii.ico")
root.resizable(False, False)
##################################################################################################################################### 
# Frame
DataEntryFrame = Frame(root,bg ="#B09B71", relief=GROOVE, borderwidth=5)
DataEntryFrame.place(x=10, y=65, width=500, height=620)
#--------------------------------------------------------------------------------------------------------------------------------
#Data Entry Frame
frontlabel = Label(DataEntryFrame, text = "-----Welcome-----", width=30, font=('times new roman', 22, 'italic bold'), bg='#87805E', fg='white')
frontlabel.pack(side=TOP, expand=True)

addbtn = Button(DataEntryFrame, text='1. Add Student', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=addstudent)
addbtn.pack(side=TOP, expand=True)

searchbtn = Button(DataEntryFrame, text='2. Search Student', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=searchstudent)
searchbtn.pack(side=TOP, expand=True)

deletebtn = Button(DataEntryFrame, text='3. Delete Student', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=deletestudent)
deletebtn.pack(side=TOP, expand=True)

updatebtn = Button(DataEntryFrame, text='4. Update Student', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=updatestudent)
updatebtn.pack(side=TOP, expand=True)

showallbtn = Button(DataEntryFrame, text='5. Show Student', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=showallstudent)
showallbtn.pack(side=TOP, expand=True)

exportbtn = Button(DataEntryFrame, text='6. Export Data', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=exportstudent)
exportbtn.pack(side=TOP, expand=True)

graphsbtn = Button(DataEntryFrame, text='7. For Graphs', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=exportgraphs)
graphsbtn.pack(side=TOP, expand=True)

exitbtn = Button(DataEntryFrame, text='8. Exit', width=25, font=('times new roman', 20, 'bold'), bd=6, bg='#A27B5C', activebackground="#EDDFB3", relief=RIDGE,
                 command=exit)
exitbtn.pack(side=TOP, expand=True)

##################################################################################################################################### 
#Data frame
ShowDataFrame = Frame(root, bg="#B09B71", relief=GROOVE, borderwidth=5)
ShowDataFrame.place(x=550, y=65, width=620, height=620)
#--------------------------------------------------------------------------------------------------------------------------------
#Show Data Frame
style = ttk.Style()
style.configure('Treeview.Heading',font=('times new roman', 20, 'bold'), foreground='black')
style.configure('Treeview',font=('times new roman', 15, 'bold'), foreground='black', background='cyan')
scroll_x = Scrollbar(ShowDataFrame, orient = HORIZONTAL)
scroll_y = Scrollbar(ShowDataFrame, orient = VERTICAL)
studenttable = Treeview(ShowDataFrame,columns=('Registration', 'Courses', 'Duration', 'The Total Fees', 'Received Fees', 'Due Fees', 'Qualification', 
                                               'Starting Date', 'Ending date', 'Full Name', 'Mobile No.', "Parent's Name", 'Address'), xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)
scroll_x.pack(side=BOTTOM, fill=X)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_x.config(command=studenttable.xview)
scroll_y.config(command=studenttable.yview)
#--------------------------------------------------------------------------------------------------------------------------------
#Headings
studenttable.heading('Registration', text='Registration')
studenttable.heading('Courses', text='Courses')
studenttable.heading('Duration', text='Duration')
studenttable.heading('The Total Fees', text='The Total Fees')
studenttable.heading('Received Fees', text='Received Fees')
studenttable.heading('Due Fees', text='Due Fees')
studenttable.heading('Qualification', text='Qualification')
studenttable.heading('Starting Date', text='Starting Date')
studenttable.heading('Ending date', text='Ending date')
studenttable.heading('Full Name', text='Full Name')
studenttable.heading('Mobile No.', text='Mobile No.')
studenttable.heading("Parent's Name", text="Parent's Name")
studenttable.heading('Address', text='Address')
studenttable['show'] = 'headings'
studenttable.column('Registration',width=160)

studenttable.pack(fill=BOTH, expand=1)
##################################################################################################################################### 
ss = "Student Analysis System"
count = 0
text = ""
##################################################################################################################################### 
# Slider
SliderLabel = Label(root, text= ss, font=('times new roman',30,"italic bold"), relief=RIDGE, borderwidth=4, width=25, bg="#87805E", fg="white")
SliderLabel.place(x=260, y=0)
IntroLabelTick()
##################################################################################################################################### 
#Clock
clock = Label(root, font=("times new roman", 14, "bold"), relief=RIDGE, borderwidth=4, bg= "#87805E", fg='white' )
clock.place(x=0, y=0)
tick()
##################################################################################################################################### 
# Connect Data Base Button
connectbutton = Button(root, text= "Connect To Database", font=('times new roman',19,"bold"), relief=RIDGE, fg='white',
                        borderwidth=4, width=16, bg="#87805E", activebackground="#EDDFB3", activeforeground='black', command=Connectdb)
connectbutton.place(x=920, y=0)

root.mainloop()
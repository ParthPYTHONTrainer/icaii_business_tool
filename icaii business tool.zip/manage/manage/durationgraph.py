import pandas as pd
from matplotlib import pyplot as plt
from tkinter import filedialog

def dua():
    ff = filedialog.askopenfile()
    # df=pd.read_csv(ff)
    duara=pd.read_csv(ff, usecols=[2])
    plt.figure(figsize=(16,9))    #graph size 
    plt.title("Duration", fontsize=20)
    plt.ylabel("Duration")
    plt.hist(duara,rwidth=0.7,color="r", edgecolor='k')
    plt.show()
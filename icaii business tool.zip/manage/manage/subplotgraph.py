import pandas as pd
from matplotlib import pyplot as plt
from tkinter import filedialog

def gra():
    ff = filedialog.askopenfile()
    df=pd.read_csv(ff)

    #plt.figure(figsize=(16,9))
    ###################################################
    plt.subplot(4,2,1)
    loc = df.loc[df["The Available Courses"]=="Web Devlopment",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    #plt.title("Web Development",loc='right')
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')

    ##################################################
    plt.subplot(4,2,2)
    loc = df.loc[df["The Available Courses"]=="Python",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ##################################################
    plt.subplot(4,2,3)
    loc = df.loc[df["The Available Courses"]=="Java",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ##################################################
    plt.subplot(4,2,4)
    loc = df.loc[df["The Available Courses"]=="AI",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ##################################################
    plt.subplot(4,2,5)
    loc = df.loc[df["The Available Courses"]=="Data Science",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ##################################################
    plt.subplot(4,2,6)
    loc = df.loc[df["The Available Courses"]=="PHP",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ##################################################
    plt.subplot(4,2,7)
    loc = df.loc[df["The Available Courses"]=="Digital Marketing",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ##################################################
    plt.subplot(4,2,8)
    loc = df.loc[df["The Available Courses"]=="C/C++",["Duration","The Available Courses"]]
    plt.xlabel("Duration")
    plt.hist(loc, orientation='vertical',rwidth=1, edgecolor='k')
    ################################################## 
    #plt.savefig("C:\\Users\\HP\Desktop\\subplot.png")
    plt.show()

# gra()
import pandas as pd
from matplotlib import pyplot as plt
from tkinter import filedialog

def qua():
    ff = filedialog.askopenfile()
    # df=pd.read_csv(ff)
    qual=pd.read_csv(ff, usecols=[6])
    plt.figure(figsize=(16,9))    #graph size 
    plt.title("Course", fontsize=20)
    plt.ylabel("Course")
    plt.hist(qual,rwidth=0.7,color="r", edgecolor='k')
    plt.show()


from datetime import date, datetime
def end_date(d,s):
    sd=s.split("/")

    if (d=="1m") and (sd[1]=="12"):
        ed=sd[0]+"/01/"+str(int(sd[2])+1)
    elif (d=="1m") and (sd[1]!="12"):
        ed=sd[0]+"/"+str(int(sd[1])+1)+"/"+sd[2]

    elif (d=="6m") and (int(sd[1])>=7):
        ed=sd[0]+"/"+str((int(sd[1])+6)-12)+"/"+str(int(sd[2])+1)
    elif (d=="6m") and (int(sd[1])<7):
        ed=sd[0]+"/"+str(int(sd[1])+6)+"/"+sd[2]

    elif (d=="1y"):
        ed=sd[0]+"/"+sd[1]+"/"+str(int(sd[2])+1)
    
    elif (d=="2m") and (int(sd[1])>=11):
        ed=sd[0]+"/"+str((int(sd[1])+2)-12)+"/"+str(int(sd[2])+1)
    elif (d=="2m") and (int(sd[1])<11):
        ed=sd[0]+"/"+str(int(sd[1])+2)+"/"+sd[2]

    elif (d=="3m") and (int(sd[1])>=10):
        ed=sd[0]+"/"+str((int(sd[1])+3)-12)+"/"+str(int(sd[2])+1)
    elif (d=="3m") and (int(sd[1])<10):
        ed=sd[0]+"/"+str(int(sd[1])+3)+"/"+sd[2]

    elif (d=="6w") and (int(sd[0])+15>30):
        month=int(sd[1])+2
        if month>12:
            ed=str(int(sd[0])-15)+"/"+ str(month-12)+"/"+str(int(sd[2])+1)
        else:
            ed=str(int(sd[0])-15)+"/"+str(month)+"/"+(sd[2])
    elif (d=="6w") and (int(sd[0])+15<=30):
        month=int(sd[1])+1
        if month>12:
            ed=str(int(sd[0])+15)+"/"+ str(month-12)+"/"+str(int(sd[2])+1)
        else:
            ed=str(int(sd[0])+15)+"/"+str(month)+"/"+(sd[2])

    return ed

# print(end_date("6w","29/5/2023"))